#!/usr/local/bin/python3
from cli import Map, Command, CommandEnviornment,CommandLoop, SyntaxHighlighter
from socket import gethostname
from threading import Thread
import socket as s
from utilities import GetIP
import os

Environment = CommandEnviornment()
loop = CommandLoop(CommandEnviornment=Environment)

cname_map = Map("info")
highlighter = SyntaxHighlighter()
cname_map.addParam(
"-i", "returns the ipaddress of the current machine", "--ip")
cname_map.addParam("-n", "returns the name of the current machine", "--name")

cname = Command(cname_map)

@cname.on("-i")
def ipv4(*args):
        ip = GetIP()
        return ip

...
@cname.on("-n")
def name(*args):
    name = gethostname()
    return name
...

exit_map = Map("exit")
exit_map.addParam("-f", "Forcefully exit the application", "--force")
exit_map.addParam("-r", f"restarts the application the application ({ highlighter.warn('WARNING: “exit -r“ is currently under development, it might duplicate operations',output=False) })", "--reload")
def delete():
    global Environment, loop
    del Environment
    loop.running = False
    del loop
    highlighter.warn('WARNING: “exit -r“ is currently under development, it might duplicate operations')
    os.system(f"./app.py")
    ...
Exit = Command(exit_map)
@Exit.on("-f")
def p(*args):
    exit()
@Exit.on("-r")
def r(*args):
    delete()


MAP = Map("server")
MAP.addParam("-a","the address to which the socket is to be bound. Enter the IP address then the port. Please note that the IP address must be the ipv4 of your machine, you can find your IPV4 using info -i", "--address") 

Server = Command(MAP)

def handleClient(conn, addr, server):
    conn.send(bytes(f"You connected to {server[0]}", "utf-8"))
    print(f"{repr(addr)} connected")

    ...

@Server.on("-a")
def startServer(*args):
    socket = s.socket(s.AF_INET, s.SOCK_STREAM)
    
    try:
        IP = args[0].strip()
        PORT = int(args[1].strip())
        ADDR = (IP, PORT)
        socket.bind((IP, PORT))
        socket.listen()
        while True:
            connection, address = socket.accept()
            client = Thread(target=handleClient,args=(connection, address, ADDR))
            client.start()
            ...
    except Exception as e:
        socket.close()
        print("Connection closed due to error")
        highlighter.error(f"{e!r}",True)


Environment.add(cname, Exit,Server)
# loop.start()